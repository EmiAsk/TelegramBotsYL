from requests import get
from io import BytesIO


API_GEOCODER = 'https://geocode-maps.yandex.ru/1.x/'
API_STATIC = 'https://static-maps.yandex.ru/1.x/'
API_KEY_GEOCODER = '40d1649f-0493-4b70-98ba-98533de7710b'


def get_coords_by_address(address: str):
    """Получение координат по адресу"""

    response = get(API_GEOCODER, params={'geocode': address,
                                         'apikey': API_KEY_GEOCODER, 'format': 'json'})

    if not response:
        raise Exception('Ошибка выполнения запроса:' +
                        f"Http статус: {response.status_code} ({response.reason})")

    toponym = response.json()["response"]["GeoObjectCollection"]["featureMember"]
    if not toponym:
        raise Exception('По данному адресу ничего не найдено!')

    toponym = toponym[0]["GeoObject"]
    coodrinates: list = toponym["Point"]["pos"].split()

    return ','.join(coodrinates)


def get_picture(address: str):
    """Сохранение картинки"""

    coords = get_coords_by_address(address)

    response = get(API_STATIC, params={'l': 'map,sat', 'll': coords, 'z': 17,
                                       'pt': coords + ',pm2rdl'})

    if not response:
        raise Exception('Ошибка выполнения запроса:' +
                        f"Http статус: {response.status_code} ({response.reason})")

    return BytesIO(response.content)


