from telegram.ext import Updater, MessageHandler, Filters
from telegram.ext import CommandHandler, ConversationHandler
from telegram import ReplyKeyboardRemove, ReplyKeyboardMarkup

from maps_api import get_picture


TOKEN = '1606352297:AAHcEj_5VsoPt3xsn8Z6wPPzop6gc5wjFio'
# @yandexlyceum2yearbot - БОТ


def start(update, context):
    update.message.reply_text(
        "Добрый день! Я бот-геокодер. Я умею искать карту заданной местности."
        "Просто введите команду /find [адрес]!")

    return 1


def search(update, context):
    address = ' '.join(context.args)
    msg = '\n\nМожете повторить команду /find или закончить командой /start'
    try:
        picture = get_picture(address)

        context.bot.send_photo(
            # caption - аннотация к фото
            update.message.chat_id, picture, caption="Нашёл!" + msg)
    except Exception as error:
        update.message.reply_text(str(error) + msg)

    return 1


def stop(update, context):
    update.message.reply_text("Всего доброго!")
    return ConversationHandler.END


updater = Updater(TOKEN, use_context=True)


dp = updater.dispatcher


conv_handler = ConversationHandler(
    entry_points=[CommandHandler('start', start)],


    states={
        1: [CommandHandler('find', search, pass_args=True)],

    },
    fallbacks=[CommandHandler('stop', stop)])

dp.add_handler(conv_handler)

updater.start_polling()

updater.idle()
