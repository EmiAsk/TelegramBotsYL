from telegram.ext import ConversationHandler, CommandHandler,\
    MessageHandler, Updater, Filters
from json import load
from telegram import ReplyKeyboardMarkup, ReplyKeyboardRemove
from random import shuffle


TOKEN = '1606352297:AAHcEj_5VsoPt3xsn8Z6wPPzop6gc5wjFio'
# @yandexlyceum2yearbot - БОТ

with open('questions.json', encoding='utf8') as file:
    QUESTIONS = load(file)['test']


def start(update, context):
    chat_id = update.message.chat_id
    cur = 0
    # храню индекс текущего вопроса. кол-во верных
    # и все вопросы под уникальным id чата в контексте
    context.user_data[chat_id] = {'current': cur, 'correct': 0, 'questions': QUESTIONS[:]}
    shuffle(context.user_data[chat_id]['questions'])
    msg = f'''Добрый день! Предлагаю пройти тест из 10 вопросов! 
Вопрос №{cur + 1}:\n\n{context.user_data[chat_id]['questions'][cur]['question']}'''
    update.message.reply_text(msg, reply_markup=ReplyKeyboardRemove())

    return 1


def answer(update, context):
    chat_id = update.message.chat_id
    cur = context.user_data[chat_id]['current']
    qs = context.user_data[chat_id]['questions']

    if qs[cur]['response'].lower() == update.message.text.lower():
        context.user_data[chat_id]['correct'] += 1

    if cur == len(qs) - 1:
        update.message.reply_text(f"Вы прошли тест! Кол-во правильных ответов: "
                                  f"{context.user_data[chat_id]['correct']}",
                                  reply_markup=ReplyKeyboardMarkup([['/start']],
                                                                   one_time_keyboard=True))

        return ConversationHandler.END

    context.user_data[chat_id]['current'] += 1
    update.message.reply_text(f"Вопрос №{cur + 2}:\n{qs[cur + 1]['question']}",
                              reply_markup=ReplyKeyboardRemove())

    return 1


def stop(update, context):
    update.message.reply_text("Всего доброго!",
                              reply_markup=ReplyKeyboardMarkup([['/start']],
                                                               one_time_keyboard=True))
    return ConversationHandler.END


updater = Updater(TOKEN)
dp = updater.dispatcher


conv_handler = ConversationHandler(
    entry_points=[CommandHandler('start', start)],


    states={
        1: [CommandHandler('stop', stop, pass_user_data=True), MessageHandler(Filters.text, answer),
]

    },
    fallbacks=[CommandHandler('stop', stop, pass_user_data=True)]
    # Точка прерывания диалога. В данном случае — команда /stop.

)


dp.add_handler(conv_handler)

updater.start_polling()

updater.idle()

